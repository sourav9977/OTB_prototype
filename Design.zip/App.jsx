
function Sidebar({ userRole, setUserRole, brandName, activeMenu, setActiveMenu, collapsed, setCollapsed }) {
  const menuItems = [
    { id: 'OTB Planning', label: 'OTB Planning', icon: '📊' },
    { id: 'Project Config', label: 'Project Config', icon: '⚙️' },
    { id: 'Analytics', label: 'Analytics', icon: '📈' },
  ];

  return (
    <div className={`bg-white border-r border-gray-200 flex flex-col transition-all duration-200 ${collapsed ? 'w-14' : 'w-52'}`}>
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 py-4 border-b border-gray-100">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
          <span className="text-white font-bold text-sm">I</span>
        </div>
        {!collapsed && <span className="text-base font-bold text-gray-900">Impetus</span>}
      </div>

      {/* Brand chip */}
      {!collapsed && (
        <div className="mx-3 my-3 bg-blue-50 rounded-lg px-3 py-2">
          <div className="text-xs text-blue-400 mb-0.5">Brand</div>
          <div className="text-sm font-semibold text-blue-700">{brandName}</div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 px-2 py-2">
        {menuItems.map(item => (
          <button key={item.id} onClick={() => setActiveMenu(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 text-sm transition-colors text-left
              ${activeMenu === item.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-50'}`}>
            <span className="text-base flex-shrink-0">{item.icon}</span>
            {!collapsed && <span>{item.label}</span>}
          </button>
        ))}
      </nav>

      {/* Role switcher */}
      {!collapsed && (
        <div className="px-3 py-3 border-t border-gray-100">
          <div className="text-xs text-gray-400 mb-2">Role (Demo)</div>
          <div className="flex flex-col gap-1">
            {['Maker','Checker','Approver'].map(r => (
              <button key={r} onClick={() => setUserRole(r)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium text-left transition-colors
                  ${userRole === r ? 'bg-blue-600 text-white' : 'text-gray-500 hover:bg-gray-100'}`}>
                {r}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Collapse toggle */}
      <button onClick={() => setCollapsed(!collapsed)}
        className="flex items-center justify-center py-3 border-t border-gray-100 text-gray-400 hover:text-gray-600 text-xs">
        {collapsed ? '→' : '← Collapse'}
      </button>
    </div>
  );
}

function App() {
  // Auth flow
  const [screen, setScreen] = React.useState('login'); // login | brand | app
  const [brand, setBrand] = React.useState('netplay');
  const [userEmail, setUserEmail] = React.useState('');

  // App state
  const [userRole, setUserRole] = React.useState('Maker');
  const [activeMenu, setActiveMenu] = React.useState('OTB Planning');
  const [sidebarCollapsed, setSidebarCollapsed] = React.useState(false);
  const [otbView, setOtbView] = React.useState('snapshot'); // snapshot | detailed
  const [selectedOTB, setSelectedOTB] = React.useState('');
  const [otbList, setOtbList] = React.useState(OTB_LIST_INITIAL);
  const [showCreateDialog, setShowCreateDialog] = React.useState(false);

  // Persist position
  React.useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('otb_state') || '{}');
      if (saved.screen) setScreen(saved.screen);
      if (saved.brand) setBrand(saved.brand);
      if (saved.userRole) setUserRole(saved.userRole);
      if (saved.otbView) setOtbView(saved.otbView);
      if (saved.selectedOTB) setSelectedOTB(saved.selectedOTB);
    } catch(e) {}
  }, []);

  React.useEffect(() => {
    try {
      localStorage.setItem('otb_state', JSON.stringify({ screen, brand, userRole, otbView, selectedOTB }));
    } catch(e) {}
  }, [screen, brand, userRole, otbView, selectedOTB]);

  const handleLogin = (email) => {
    setUserEmail(email);
    // Auto-assign role from email for demo
    if (email.includes('anusha')) setUserRole('Approver');
    else if (email.includes('testuser')) setUserRole('Checker');
    else setUserRole('Maker');
    setScreen('brand');
  };

  const handleBrandContinue = (brandId) => {
    setBrand(brandId);
    setScreen('app');
  };

  const brandNames = { netplay:'Netplay', teamspirit:'Teamspirit', dnmx:'DNMX', yousta:'Yousta', altheory:'Altheory' };

  const handleOpenOTB = (otbId) => {
    setSelectedOTB(otbId);
    setOtbView('detailed');
  };

  const handleUpdateStatus = (otbId, newStatus) => {
    setOtbList(prev => prev.map(o => o.id === otbId ? { ...o, status: newStatus } : o));
  };

  const handleCreateOTB = (form) => {
    const newId = `OTB_${form.versionName}_${Date.now()}`;
    setOtbList(prev => [{ id: newId, status: 'in_progress', createdBy: 'Sourav Nayak' }, ...prev]);
    setShowCreateDialog(false);
  };

  const otbStatusKey = otbList.find(o => o.id === selectedOTB)?.status || 'in_progress';

  if (screen === 'login') return <LoginPage onLogin={handleLogin} />;
  if (screen === 'brand') return <BrandSelectionPage onContinue={handleBrandContinue} />;

  return (
    <div className="h-screen flex flex-col bg-gray-50 overflow-hidden">
      {/* Top nav */}
      <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between z-10 flex-shrink-0">
        <div className="flex items-center gap-4">
          <div className="text-sm text-gray-500">
            OTB Planning
            {otbView === 'detailed' && selectedOTB && (
              <> <span className="mx-1 text-gray-300">/</span>
                <span className="text-gray-700 font-mono text-xs">{selectedOTB}</span>
              </>
            )}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-xs text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">{userRole}</div>
          <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">
            {userEmail ? userEmail[0].toUpperCase() : 'S'}
          </div>
        </div>
      </header>

      <div className="flex flex-1 min-h-0">
        <Sidebar
          userRole={userRole} setUserRole={setUserRole}
          brandName={brandNames[brand] || 'Netplay'}
          activeMenu={activeMenu} setActiveMenu={setActiveMenu}
          collapsed={sidebarCollapsed} setCollapsed={setSidebarCollapsed}
        />

        <main className="flex-1 flex flex-col min-h-0 overflow-hidden">
          {activeMenu === 'OTB Planning' ? (
            otbView === 'snapshot' ? (
              <SnapshotView
                userRole={userRole}
                brandName={brandNames[brand]}
                onOpenOTB={handleOpenOTB}
                onCreateOTB={() => setShowCreateDialog(true)}
                otbList={otbList}
                onUpdateStatus={handleUpdateStatus}
              />
            ) : (
              <KpiTable
                userRole={userRole}
                selectedOTB={selectedOTB}
                otbStatus={otbStatusKey}
                onBack={() => setOtbView('snapshot')}
                onUpdateStatus={(id, status) => { handleUpdateStatus(id, status); }}
              />
            )
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">
              {activeMenu} — coming soon
            </div>
          )}
        </main>
      </div>

      {showCreateDialog && (
        <CreateOTBDialog onClose={() => setShowCreateDialog(false)} onCreate={handleCreateOTB} />
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
