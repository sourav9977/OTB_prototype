
function StatusBadge({ statusText, statusKey }) {
  const key = statusKey || STATUS_TEXT_MAP[statusText] || 'in_progress';
  const cfg = STATUS_CONFIG[key] || STATUS_CONFIG['in_progress'];
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>
      {cfg.label || statusText}
    </span>
  );
}

function ConfirmDialog({ config, onProceed, onViewOTB, onClose }) {
  if (!config) return null;
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 max-w-sm w-full mx-4">
        <h3 className="text-base font-semibold text-gray-900 mb-2">Confirm Action</h3>
        <p className="text-sm text-gray-600 mb-2">{config.message}</p>
        {config.disclaimer && (
          <p className="text-xs text-orange-600 bg-orange-50 px-3 py-2 rounded mb-4">{config.disclaimer}</p>
        )}
        <div className="text-xs text-gray-500 mb-5 font-mono bg-gray-50 px-3 py-2 rounded truncate">{config.otbName}</div>
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">Cancel</button>
          <button onClick={onViewOTB} className="flex-1 px-4 py-2 border border-blue-300 rounded-lg text-sm text-blue-700 hover:bg-blue-50">View OTB</button>
          <button onClick={onProceed} className="flex-1 px-4 py-2 bg-blue-600 rounded-lg text-sm text-white hover:bg-blue-700">Proceed</button>
        </div>
      </div>
    </div>
  );
}

function SnapshotView({ userRole, brandName, onOpenOTB, onCreateOTB, otbList, onUpdateStatus }) {
  const defaultTabs = { Maker: 'Creation', Checker: 'Review', Approver: 'Approval' };
  const [activeTab, setActiveTab] = React.useState(defaultTabs[userRole] || 'Creation');
  const [confirmConfig, setConfirmConfig] = React.useState(null);
  const [successMsg, setSuccessMsg] = React.useState('');

  React.useEffect(() => {
    setActiveTab(defaultTabs[userRole] || 'Creation');
  }, [userRole]);

  const tabs = ['Creation','Review','Approval','Completed','Expired'];

  const tabDesc = {
    'Creation': 'OTBs currently being drafted by makers.',
    'Review': 'OTBs submitted for checker review.',
    'Approval': 'OTBs pending final approver sign-off.',
    'Completed': 'Approved OTBs ready for execution.',
    'Expired': 'OTBs that have passed their validity period.'
  };

  // Merge static snapshot data with live status
  const getRows = () => {
    const base = OTB_SNAPSHOT_DATA[activeTab] || [];
    return base.map(row => {
      const live = otbList.find(o => o.id === row.id);
      return { ...row, status: live ? STATUS_CONFIG[live.status]?.label || row.status : row.status };
    }).filter(row => {
      // filter based on live status matching this tab
      const live = otbList.find(o => o.id === row.id);
      if (!live) return true;
      const tabStatuses = {
        'Creation': ['in_progress','change_requested'],
        'Review': ['in_review'],
        'Approval': ['pending_approval'],
        'Completed': ['approved'],
        'Expired': ['expired']
      };
      return (tabStatuses[activeTab] || []).includes(live.status);
    });
  };

  const rows = getRows();

  const getActions = (row) => {
    const live = otbList.find(o => o.id === row.id);
    if (!live) return [];
    const s = live.status;
    if (activeTab === 'Creation' && userRole === 'Maker' && (s === 'in_progress' || s === 'change_requested'))
      return [{ action: 'send_review', label: 'Send for Review' }];
    if (activeTab === 'Review' && userRole === 'Checker' && s === 'in_review')
      return [{ action: 'send_approval', label: 'Send for Approval' }, { action: 'request_change', label: 'Request Change' }];
    if (activeTab === 'Approval' && userRole === 'Approver' && s === 'pending_approval')
      return [{ action: 'approve', label: 'Approve OTB' }];
    if (activeTab === 'Completed')
      return [{ action: 'view_breakup', label: 'View Breakup' }];
    return [];
  };

  const showActionsCol = ['Creation','Review','Approval','Completed'].includes(activeTab);
  const dateHeader = activeTab === 'Completed' ? 'Approved On' : 'Expiring On';

  const actionConfigs = {
    send_review:   { message: 'Send this OTB for checker review?', newStatus: 'in_review',        successMessage: 'OTB sent for review' },
    send_approval: { message: 'Send this OTB for approver review?', newStatus: 'pending_approval', successMessage: 'OTB sent for approval' },
    request_change:{ message: 'Request changes from the maker?', newStatus: 'change_requested',   successMessage: 'Change request sent' },
    approve:       { message: 'Approve this OTB?', disclaimer: 'Note: This cannot be reversed.', newStatus: 'approved', successMessage: 'OTB approved' },
  };

  const handleAction = (action, row) => {
    if (action === 'view_breakup') { alert('OTB Breakup — coming soon'); return; }
    const cfg = actionConfigs[action];
    if (!cfg) return;
    setConfirmConfig({ ...cfg, otbName: row.id, otbRow: row });
  };

  const handleProceed = () => {
    onUpdateStatus(confirmConfig.otbName, confirmConfig.newStatus);
    setSuccessMsg(confirmConfig.successMessage);
    setConfirmConfig(null);
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleViewOTB = () => {
    onOpenOTB(confirmConfig.otbName);
    setConfirmConfig(null);
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="text-xs text-gray-400 uppercase tracking-wider mb-1">OTB Planning — {brandName}</div>
          <h1 className="text-xl font-bold text-gray-900">OTB Snapshot</h1>
        </div>
        {userRole === 'Maker' && (
          <button onClick={onCreateOTB}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
            <span className="text-lg leading-none">+</span> Create OTB
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-0 border-b border-gray-200 mb-5">
        {tabs.map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-5 py-2.5 text-sm font-medium border-b-2 transition-colors ${activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {tab}
            <span className="ml-1.5 text-xs bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-full">
              {(OTB_SNAPSHOT_DATA[tab] || []).length}
            </span>
          </button>
        ))}
      </div>

      <p className="text-xs text-gray-400 mb-4">{tabDesc[activeTab]}</p>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden flex-1">
        {rows.length === 0 ? (
          <div className="flex items-center justify-center h-40 text-gray-400 text-sm">No OTBs in this category</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">OTB Version</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Season</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Month</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Created On</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">{dateHeader}</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                {showActionsCol && <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => {
                const actions = getActions(row);
                return (
                  <tr key={row.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${i % 2 === 0 ? '' : 'bg-gray-50/30'}`}>
                    <td className="px-4 py-3">
                      <button onClick={() => onOpenOTB(row.id)}
                        className="text-blue-600 hover:text-blue-800 font-mono text-xs hover:underline text-left">
                        {row.id}
                      </button>
                    </td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{row.season}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{row.month}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{row.createdOn}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{row.expiringOn || row.approvedOn || '—'}</td>
                    <td className="px-4 py-3"><StatusBadge statusText={row.status} /></td>
                    {showActionsCol && (
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          {actions.map(a => (
                            <button key={a.action} onClick={() => handleAction(a.action, row)}
                              className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                                a.action === 'request_change' ? 'border border-orange-300 text-orange-700 hover:bg-orange-50' :
                                a.action === 'approve' ? 'bg-green-600 text-white hover:bg-green-700' :
                                'bg-blue-600 text-white hover:bg-blue-700'
                              }`}>
                              {a.label}
                            </button>
                          ))}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Toasts */}
      {successMsg && (
        <div className="fixed bottom-6 right-6 bg-green-600 text-white px-5 py-3 rounded-lg shadow-lg text-sm animate-fade-in">
          ✓ {successMsg}
        </div>
      )}

      <ConfirmDialog config={confirmConfig} onProceed={handleProceed} onViewOTB={handleViewOTB} onClose={() => setConfirmConfig(null)} />
    </div>
  );
}

function CreateOTBDialog({ onClose, onCreate }) {
  const [form, setForm] = React.useState({ versionName: '', hit: '', drop: '', year: '' });
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const handleSubmit = () => {
    if (!form.versionName || !form.hit || !form.drop || !form.year) { alert('Please fill all fields'); return; }
    onCreate(form);
  };
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 max-w-sm w-full mx-4">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-semibold text-gray-900">Create New OTB</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
        </div>
        {[['Version Name','versionName','text'],['Hit (Season)','hit','text'],['Drop','drop','text'],['Year','year','number']].map(([label, key, type]) => (
          <div key={key} className="mb-4">
            <label className="block text-xs text-gray-600 mb-1.5">{label}</label>
            <input type={type} value={form[key]} onChange={e => set(key, e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
        ))}
        <div className="flex gap-2 mt-6">
          <button onClick={onClose} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">Cancel</button>
          <button onClick={handleSubmit} className="flex-1 px-4 py-2 bg-blue-600 rounded-lg text-sm text-white hover:bg-blue-700">Create</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SnapshotView, CreateOTBDialog, StatusBadge, ConfirmDialog });
