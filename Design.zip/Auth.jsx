
function LoginPage({ onLogin }) {
  const [email, setEmail] = React.useState('sourav@fynd.team');
  const [password, setPassword] = React.useState('password123');

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin(email);
  };

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2">
      {/* Left — brand panel */}
      <div className="bg-gray-50 flex flex-col items-center justify-center p-12">
        <div className="max-w-md w-full">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-11 h-11 bg-blue-600 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-lg">I</span>
            </div>
            <span className="text-2xl font-bold text-gray-900">Impetus</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4 leading-tight">
            Streamlining Your Costing Operations with Precision and Agility
          </h1>
          <p className="text-gray-500 mt-4 text-sm leading-relaxed">
            Open-To-Buy planning tool for retail and fashion merchandising teams.
            Plan, review, and approve weekly buy budgets through a structured workflow.
          </p>
          {/* placeholder image */}
          <div className="mt-10 rounded-xl bg-gray-200 aspect-video flex items-center justify-center">
            <div style={{fontFamily:'monospace',color:'#aaa',fontSize:'12px',textAlign:'center'}}>
              [ dashboard preview ]
            </div>
          </div>
        </div>
      </div>

      {/* Right — login form */}
      <div className="bg-white flex items-center justify-center p-12">
        <div className="w-full max-w-sm">
          <h2 className="text-3xl font-bold text-gray-900 mb-10">Login</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-5">
              <label className="block text-sm text-gray-600 mb-1.5">Email ID / Mobile Number</label>
              <input
                type="text" value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter email"
              />
            </div>
            <div className="mb-2">
              <label className="block text-sm text-gray-600 mb-1.5">Password</label>
              <input
                type="password" value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter password"
              />
            </div>
            <div className="mb-6 text-right">
              <a href="#" className="text-sm text-blue-600 hover:underline">Forgot password?</a>
            </div>
            <button type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
              Login
            </button>
            <div className="mt-6 text-center text-sm text-gray-500">— OR —</div>
            <div className="mt-4 text-center text-sm text-gray-600">
              Fynd / Reliance employee?{' '}
              <a href="#" className="text-blue-600 font-medium hover:underline">Login here</a>
            </div>
          </form>

          {/* Quick-login hints */}
          <div className="mt-8 bg-blue-50 rounded-lg p-4 text-xs text-blue-700">
            <div className="font-semibold mb-2">Demo accounts:</div>
            {[
              ['sourav@fynd.team','Maker'],
              ['testuser@fynd.team','Checker'],
              ['anusha@fynd.team','Approver'],
            ].map(([e,r]) => (
              <div key={e} className="flex justify-between cursor-pointer hover:text-blue-900 py-0.5"
                onClick={() => { setEmail(e); setPassword('password123'); }}>
                <span>{e}</span><span className="font-medium">{r}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function BrandSelectionPage({ onContinue }) {
  const [selected, setSelected] = React.useState('netplay');
  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-8">
      <div className="bg-white border border-gray-200 rounded-xl shadow-lg p-8 max-w-md w-full">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">I</span>
          </div>
          <span className="text-xl font-bold text-gray-900">Impetus</span>
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-1">Select Brand</h2>
        <p className="text-sm text-gray-500 mb-6">Choose the brand you want to plan for</p>

        <div className="space-y-2 mb-8">
          {BRANDS.map(b => (
            <label key={b.id}
              className={`flex items-center gap-3 p-3.5 rounded-lg border cursor-pointer transition-colors ${selected === b.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
              <input type="radio" name="brand" value={b.id} checked={selected === b.id}
                onChange={() => setSelected(b.id)} className="accent-blue-600" />
              <div className="w-8 h-8 rounded-md bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-500">
                {b.name[0]}
              </div>
              <span className="text-sm font-medium text-gray-800">{b.name}</span>
            </label>
          ))}
        </div>
        <button onClick={() => onContinue(selected)}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
          Continue
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { LoginPage, BrandSelectionPage });
