
const OTB_LIST_INITIAL = [
  { id: 'OTB_31_10_2025_120804', status: 'in_progress', createdBy: 'Sourav Nayak' },
  { id: 'OTB_01_10_2025_171500', status: 'change_requested', createdBy: 'Sourav Nayak' },
  { id: 'OTB_22_10_2025_190523', status: 'in_review', createdBy: 'Test User' },
  { id: 'OTB_17_10_2025_130922', status: 'change_requested', createdBy: 'Chinta Anusha' },
  { id: 'OTB_14_10_2025_123327', status: 'pending_approval', createdBy: 'Sourav Nayak' },
  { id: 'OTB_9_10_2025_120219_style_data', status: 'approved', createdBy: 'Test User' },
  { id: 'OTB_8_10_2025_191623', status: 'in_progress', createdBy: 'Chinta Anusha' },
  { id: 'OTB_8_10_2025_175007', status: 'in_review', createdBy: 'Sourav Nayak' },
  { id: 'OTB_8_10_2025_154823_rk2', status: 'approved', createdBy: 'Test User' }
];

const OTB_SNAPSHOT_DATA = {
  'Creation': [
    { id: 'OTB_31_10_2025_120804', season: 'H1', month: 'January', createdOn: '31/10/25', expiringOn: '15/11/25', status: 'In Progress' },
    { id: 'OTB_01_10_2025_171500', season: 'H1', month: 'January', createdOn: '01/10/25', expiringOn: '15/10/25', status: 'Change Requested' },
    { id: 'OTB_17_10_2025_130922', season: 'H1', month: 'January', createdOn: '17/10/25', expiringOn: '31/10/25', status: 'Change Requested' },
    { id: 'OTB_8_10_2025_191623', season: 'H1', month: 'January', createdOn: '08/10/25', expiringOn: '22/10/25', status: 'In Progress' }
  ],
  'Review': [
    { id: 'OTB_22_10_2025_190523', season: 'H1', month: 'January', createdOn: '22/10/25', expiringOn: '05/11/25', status: 'In Review' },
    { id: 'OTB_8_10_2025_175007', season: 'H1', month: 'January', createdOn: '08/10/25', expiringOn: '22/10/25', status: 'In Review' }
  ],
  'Approval': [
    { id: 'OTB_14_10_2025_123327', season: 'H1', month: 'January', createdOn: '14/10/25', expiringOn: '28/10/25', status: 'Pending Approval' }
  ],
  'Completed': [
    { id: 'OTB_9_10_2025_120219_style_data', season: 'H1', month: 'January', createdOn: '09/10/25', approvedOn: '23/10/25', status: 'Approved' },
    { id: 'OTB_8_10_2025_154823_rk2', season: 'H1', month: 'January', createdOn: '08/10/25', approvedOn: '22/10/25', status: 'Approved' }
  ],
  'Expired': []
};

const BRANDS = [
  { id: 'netplay', name: 'Netplay' },
  { id: 'teamspirit', name: 'Teamspirit' },
  { id: 'dnmx', name: 'DNMX' },
  { id: 'yousta', name: 'Yousta' },
  { id: 'altheory', name: 'Altheory' }
];

const STATUS_CONFIG = {
  'in_progress':      { color: 'bg-gray-100 text-gray-700',    label: 'In Progress' },
  'in_review':        { color: 'bg-blue-100 text-blue-700',    label: 'In Review' },
  'change_requested': { color: 'bg-yellow-100 text-yellow-700',label: 'Change Requested' },
  'pending_approval': { color: 'bg-orange-100 text-orange-700',label: 'Pending Approval' },
  'approved':         { color: 'bg-green-100 text-green-700',  label: 'Approved' },
  'expired':          { color: 'bg-gray-100 text-gray-400',    label: 'Expired' }
};

const STATUS_TEXT_MAP = {
  'In Progress': 'in_progress',
  'Change Requested': 'change_requested',
  'In Review': 'in_review',
  'Pending Approval': 'pending_approval',
  'Approved': 'approved',
  'Expired': 'expired'
};

// KPI table rows definition
const KPI_ROWS = [
  { key: 'section_sales', label: 'Sales', isSection: true },
  { key: 'netSalesAOP', label: 'AOP Net Sales (INR)', group: 'sales', indent: 1 },
  { key: 'netSalesCY', label: 'CY Net Sales (INR)', group: 'sales', indent: 1 },
  { key: 'netSalesLY', label: 'LY Net Sales (INR)', group: 'sales', indent: 1 },
  { key: 'achievementAOP', label: 'Achievement vs AOP (%)', group: 'sales', indent: 1 },
  { key: 'changeLY', label: 'Change Over LY (%)', group: 'sales', indent: 1 },
  { key: 'section_asp', label: 'ASP / MRP / Discount', isSection: true },
  { key: 'mrpCY', label: 'CY MRP (INR)', group: 'asp', indent: 1 },
  { key: 'discountCY', label: 'CY Discount (%)', group: 'asp', indent: 1 },
  { key: 'aspCY', label: 'CY ASP (INR)', group: 'asp', indent: 1 },
  { key: 'section_units', label: 'Unit Sales', isSection: true },
  { key: 'unitSalesCY', label: 'CY Unit Sales', group: 'units', indent: 1 },
  { key: 'unitSalesLY', label: 'LY Unit Sales', group: 'units', indent: 1 },
  { key: 'section_otb', label: 'Inventory & OTB', isSection: true },
  { key: 'targetInventory', label: 'Target Inventory (Qty)', group: 'otb', indent: 1 },
  { key: 'openingStock', label: 'Opening Stock (Qty)', group: 'otb', indent: 1 },
  { key: 'plannedInwards', label: 'Planned Inwards (Qty)', group: 'otb', indent: 1 },
  { key: 'additionalInwards', label: 'Additional Inwards (Qty)', group: 'otb', indent: 1, editable: true },
  { key: 'targetCover', label: 'Target Cover (Weeks)', group: 'otb', indent: 1, editable: true },
  { key: 'actualCover', label: 'Actual Cover (Weeks)', group: 'otb', indent: 1 },
  { key: 'otbUnits', label: 'OTB Units (Qty)', group: 'otb', indent: 1, highlight: true },
  { key: 'otbCogs', label: 'OTB COGS (INR)', group: 'otb', indent: 1, highlight: true },
];

// Actual data (10 weeks: W19-W28)
const ACTUAL_DATA = {
  netSalesAOP:    [4200000,4350000,4180000,4420000,4300000,4500000,4250000,4380000,4100000,4220000],
  netSalesCY:     [3980000,4120000,3950000,4280000,4150000,4380000,4050000,4200000,3980000,4100000],
  netSalesLY:     [3750000,3900000,3720000,4050000,3920000,4150000,3830000,3970000,3760000,3880000],
  achievementAOP: [94.8,94.7,94.5,96.8,96.5,97.3,95.3,95.9,97.1,97.2],
  changeLY:       [6.1,5.6,6.2,5.7,5.9,5.5,5.7,5.8,5.9,5.7],
  mrpCY:          [899,899,899,999,999,999,949,949,879,879],
  discountCY:     [22.1,22.1,22.2,21.8,21.8,21.9,22.0,22.1,22.3,22.3],
  aspCY:          [700,700,699,781,781,779,740,739,683,683],
  unitSalesCY:    [5686,5886,5651,5480,5314,5622,5473,5683,5828,6003],
  unitSalesLY:    [5325,5520,5300,5150,4980,5280,5130,5320,5460,5630],
  targetInventory:[6019,6019,6019,6019,6019,6019,6019,6019,6019,6019],
  openingStock:   [119469,125155,130703,136154,141468,146782,152104,157578,162752,156733],
  plannedInwards: [7032,7032,7032,7032,7032,7032,7032,7032,7032,7032],
  additionalInwards:[0,0,0,0,0,0,0,0,0,0],
  targetCover:    [8,8,8,8,8,8,8,8,8,8],
  actualCover:    [21,22,23,24,25,26,27,28,27,26],
  otbUnits:       [-113450,-118423,-123099,-125748.5,-128628.33,-131662.89,-136457.89,-141186.89,6019.11,6019.11],
  otbCogs:        [-34207003,-35375362,-37021849,-37396368,-37903476,-39221436,-40993699,-42461009,0,0],
};

// Projected defaults (3 weeks: W29-W31)
const PROJECTED_DEFAULTS = {
  netSalesAOP:    [4300000, 4400000, 4350000],
  netSalesCY:     [4150000, 4250000, 4200000],
  netSalesLY:     [3920000, 4010000, 3970000],
  achievementAOP: [96.5, 96.6, 96.6],
  changeLY:       [5.9, 6.0, 5.8],
  mrpCY:          [949, 949, 949],
  discountCY:     [22.0, 22.0, 22.0],
  aspCY:          [740, 740, 740],
  unitSalesCY:    [5612, 5744, 5678],
  unitSalesLY:    [5260, 5380, 5320],
  targetInventory:[6019, 6019, 6019],
  openingStock:   [150714, 143682, 137938],
  plannedInwards: [7032, 7285, 4085],
  additionalInwards:[0, 0, 0],
  targetCover:    [8, 8, 8],
  actualCover:    [25, 24, 23],
  otbUnits:       [-1012.89, -8297.39, -12382.56],
  otbCogs:        [-765813, -6295195, -9441583],
};

const WEEKS_ACTUAL = ['W19','W20','W21','W22','W23','W24','W25','W26','W27','W28'];
const WEEKS_PROJ = ['W29','W30','W31'];

Object.assign(window, {
  OTB_LIST_INITIAL, OTB_SNAPSHOT_DATA, BRANDS,
  STATUS_CONFIG, STATUS_TEXT_MAP, KPI_ROWS,
  ACTUAL_DATA, PROJECTED_DEFAULTS,
  WEEKS_ACTUAL, WEEKS_PROJ
});
