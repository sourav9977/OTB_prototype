
function fmt(val, key) {
  if (val === null || val === undefined) return '—';
  const n = Number(val);
  if (isNaN(n)) return val;
  if (key && (key.includes('Cogs') || key.includes('Sales') || key.includes('mrp') || key.includes('asp'))) {
    return n < 0
      ? `(${Math.abs(n).toLocaleString('en-IN', { maximumFractionDigits: 0 })})`
      : n.toLocaleString('en-IN', { maximumFractionDigits: 0 });
  }
  if (key && (key.includes('achievement') || key.includes('change') || key.includes('discount') || key.includes('margin'))) {
    return (n > 0 ? '' : '') + n.toFixed(1) + '%';
  }
  if (Math.abs(n) >= 1000) {
    return n < 0
      ? `(${Math.abs(n).toLocaleString('en-IN', { maximumFractionDigits: 0 })})`
      : n.toLocaleString('en-IN', { maximumFractionDigits: 0 });
  }
  return n.toFixed(n % 1 !== 0 ? 1 : 0);
}

function ReviewModal({ changes, onSave, onDiscard }) {
  if (!changes) return null;
  const kpiNames = {
    targetCover: 'Target Cover (Weeks)',
    targetInventory: 'Target Inventory (Qty)',
    additionalInwards: 'Additional Inwards (Qty)',
    otbUnits: 'OTB Units (Qty)',
    otbCogs: 'OTB COGS (INR)',
  };
  const pct = (o, n) => {
    if (o === 0) return '—';
    const c = ((n - o) / Math.abs(o)) * 100;
    return (c > 0 ? '+' : '') + c.toFixed(1) + '%';
  };
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 max-w-lg w-full mx-4">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-base font-semibold text-gray-900">Review Changes — {changes.columnName}</h3>
          <button onClick={onDiscard} className="text-gray-400 hover:text-gray-600 text-lg leading-none">✕</button>
        </div>
        <p className="text-xs text-gray-500 mb-5">Review the impact of your edit before saving.</p>
        <table className="w-full text-sm mb-6">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left pb-2 text-xs font-semibold text-gray-500">KPI</th>
              <th className="text-right pb-2 text-xs font-semibold text-gray-500">Old</th>
              <th className="text-right pb-2 text-xs font-semibold text-gray-500">New</th>
              <th className="text-right pb-2 text-xs font-semibold text-gray-500">Change</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(changes.changes).map(([kpi, { old: o, new: n }]) => {
              const delta = n - o;
              const isPos = delta >= 0;
              return (
                <tr key={kpi} className="border-b border-gray-100">
                  <td className="py-2.5 text-gray-700">{kpiNames[kpi] || kpi}</td>
                  <td className="py-2.5 text-right text-gray-500 font-mono text-xs">{fmt(o, kpi)}</td>
                  <td className="py-2.5 text-right font-mono text-xs font-semibold text-gray-900">{fmt(n, kpi)}</td>
                  <td className={`py-2.5 text-right text-xs font-medium ${isPos ? 'text-green-600' : 'text-red-600'}`}>
                    {pct(o, n)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <div className="flex gap-2">
          <button onClick={onDiscard} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">Discard</button>
          <button onClick={onSave} className="flex-1 px-4 py-2 bg-blue-600 rounded-lg text-sm text-white hover:bg-blue-700">Save Changes</button>
        </div>
      </div>
    </div>
  );
}

function KpiTable({ userRole, selectedOTB, otbStatus, onBack, onUpdateStatus }) {
  const [projData, setProjData] = React.useState({ ...PROJECTED_DEFAULTS });
  const [editingCell, setEditingCell] = React.useState(null); // { rowKey, wIdx }
  const [tempVal, setTempVal] = React.useState('');
  const [reviewChanges, setReviewChanges] = React.useState(null);
  const [hasUnsaved, setHasUnsaved] = React.useState(false);
  const [savedToast, setSavedToast] = React.useState(false);
  const [accessToast, setAccessToast] = React.useState(false);

  const canEdit = userRole === 'Maker' && (otbStatus === 'in_progress' || otbStatus === 'change_requested');

  const getCellValue = (rowKey, colIdx) => {
    // colIdx 0..9 = actual, 10..12 = projected
    if (colIdx < 10) return ACTUAL_DATA[rowKey]?.[colIdx] ?? null;
    return projData[rowKey]?.[colIdx - 10] ?? null;
  };

  const handleCellClick = (rowKey, colIdx) => {
    if (colIdx < 10) return;
    const row = KPI_ROWS.find(r => r.key === rowKey);
    if (!row?.editable) return;
    if (!canEdit) {
      setAccessToast(true);
      setTimeout(() => setAccessToast(false), 3000);
      return;
    }
    const wIdx = colIdx - 10;
    setEditingCell({ rowKey, wIdx });
    setTempVal(String(projData[rowKey]?.[wIdx] ?? 0));
  };

  const commitEdit = () => {
    if (!editingCell) return;
    const { rowKey, wIdx } = editingCell;
    const newVal = parseFloat(tempVal) || 0;

    if (rowKey === 'targetCover') {
      if (newVal <= 0) { alert('Target Cover must be > 0'); return; }
      const old = projData.targetCover[wIdx];
      const plannedInwards = projData.plannedInwards[wIdx];
      const additionalInwards = projData.additionalInwards[wIdx];
      const avgWeeklySales = ACTUAL_DATA.unitSalesCY.slice(-4).reduce((a,b)=>a+b,0)/4;
      const newTargetInventory = Math.round(newVal * avgWeeklySales);
      const openingStock = projData.openingStock[wIdx];
      const newOtbUnits = Math.round(newTargetInventory - openingStock - plannedInwards - additionalInwards);
      const cyCogs = ACTUAL_DATA.aspCY[ACTUAL_DATA.aspCY.length - 1] * 0.756;
      const newOtbCogs = Math.round(newOtbUnits * cyCogs);

      setReviewChanges({
        columnName: WEEKS_PROJ[wIdx],
        changes: {
          targetCover: { old, new: newVal },
          targetInventory: { old: projData.targetInventory[wIdx], new: newTargetInventory },
          otbUnits: { old: projData.otbUnits[wIdx], new: newOtbUnits },
          otbCogs: { old: projData.otbCogs[wIdx], new: newOtbCogs },
        }
      });
    } else if (rowKey === 'additionalInwards') {
      const old = projData.additionalInwards[wIdx];
      const newOtbUnits = Math.round(projData.targetInventory[wIdx] - projData.openingStock[wIdx] - projData.plannedInwards[wIdx] - newVal);
      const cyCogs = ACTUAL_DATA.aspCY[ACTUAL_DATA.aspCY.length - 1] * 0.756;
      const newOtbCogs = Math.round(newOtbUnits * cyCogs);
      setReviewChanges({
        columnName: WEEKS_PROJ[wIdx],
        changes: {
          additionalInwards: { old, new: newVal },
          otbUnits: { old: projData.otbUnits[wIdx], new: newOtbUnits },
          otbCogs: { old: projData.otbCogs[wIdx], new: newOtbCogs },
        }
      });
    }
    setEditingCell(null);
    setTempVal('');
  };

  const handleSaveReview = () => {
    const { changes } = reviewChanges;
    const colIdx = WEEKS_PROJ.indexOf(reviewChanges.columnName);
    setProjData(prev => {
      const next = { ...prev };
      Object.entries(changes).forEach(([k, { new: n }]) => {
        const arr = [...(next[k] || [0,0,0])];
        arr[colIdx] = n;
        next[k] = arr;
      });
      return next;
    });
    setReviewChanges(null);
    setHasUnsaved(true);
  };

  const handleSaveOTB = () => {
    setHasUnsaved(false);
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  const statusCfg = STATUS_CONFIG[otbStatus] || STATUS_CONFIG['in_progress'];

  const getActionButtons = () => {
    const btns = [];
    if (userRole === 'Maker' && (otbStatus === 'in_progress' || otbStatus === 'change_requested'))
      btns.push({ label: 'Send for Review', action: 'in_review', style: 'blue' });
    if (userRole === 'Checker' && otbStatus === 'in_review') {
      btns.push({ label: 'Send for Approval', action: 'pending_approval', style: 'blue' });
      btns.push({ label: 'Request Changes', action: 'change_requested', style: 'orange' });
    }
    if (userRole === 'Approver' && otbStatus === 'pending_approval')
      btns.push({ label: 'Approve OTB', action: 'approved', style: 'green' });
    return btns;
  };

  const workflowSteps = [
    { key: 'in_progress', label: 'In Progress' },
    { key: 'in_review', label: 'In Review' },
    { key: 'pending_approval', label: 'Pending Approval' },
    { key: 'approved', label: 'Approved' },
  ];
  const stepOrder = { in_progress:0, change_requested:1, in_review:1, pending_approval:2, approved:3 };
  const currentStep = stepOrder[otbStatus] ?? 0;

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Top bar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-4">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-800 transition-colors">
          <span>←</span> Back
        </button>
        <div className="h-4 w-px bg-gray-200" />
        <span className="text-xs font-mono text-gray-500 truncate max-w-xs">{selectedOTB}</span>
        <StatusBadge statusKey={otbStatus} />
        <div className="flex-1" />
        {canEdit && hasUnsaved && (
          <button onClick={handleSaveOTB} className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">Save OTB</button>
        )}
        {getActionButtons().map(btn => (
          <button key={btn.action} onClick={() => onUpdateStatus(selectedOTB, btn.action)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              btn.style === 'orange' ? 'border border-orange-300 text-orange-700 hover:bg-orange-50' :
              btn.style === 'green' ? 'bg-green-600 text-white hover:bg-green-700' :
              'bg-blue-600 text-white hover:bg-blue-700'
            }`}>
            {btn.label}
          </button>
        ))}
      </div>

      {/* Workflow stepper */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 py-3">
        <div className="flex items-center gap-0 max-w-lg">
          {workflowSteps.map((step, i) => (
            <React.Fragment key={step.key}>
              <div className="flex items-center gap-2">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold
                  ${i < currentStep ? 'bg-blue-600 text-white' :
                    i === currentStep ? 'bg-blue-600 text-white ring-4 ring-blue-100' :
                    'bg-gray-200 text-gray-500'}`}>
                  {i < currentStep ? '✓' : i + 1}
                </div>
                <span className={`text-xs ${i === currentStep ? 'font-semibold text-blue-700' : i < currentStep ? 'text-blue-600' : 'text-gray-400'}`}>
                  {step.label}
                </span>
              </div>
              {i < workflowSteps.length - 1 && (
                <div className={`h-px w-8 mx-2 ${i < currentStep ? 'bg-blue-400' : 'bg-gray-300'}`} />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* KPI Table */}
      <div className="flex-1 overflow-auto p-4">
        <div className="inline-block min-w-full">
          <table className="text-xs border-collapse" style={{tableLayout:'fixed', minWidth:'1400px'}}>
            <colgroup>
              <col style={{width:'200px'}} />
              {WEEKS_ACTUAL.map(w => <col key={w} style={{width:'80px'}} />)}
              {WEEKS_PROJ.map(w => <col key={w} style={{width:'88px'}} />)}
            </colgroup>
            <thead>
              <tr>
                <th className="bg-gray-50 sticky left-0 z-10 border border-gray-200 px-3 py-2 text-left text-xs font-semibold text-gray-600">KPI</th>
                {/* Actual header group */}
                {WEEKS_ACTUAL.map(w => (
                  <th key={w} className="bg-gray-50 border border-gray-200 px-2 py-2 text-center text-xs font-semibold text-gray-500">{w}</th>
                ))}
                {/* Projected header group */}
                {WEEKS_PROJ.map(w => (
                  <th key={w} className="bg-blue-50 border border-blue-200 px-2 py-2 text-center text-xs font-semibold text-blue-600">{w} ✎</th>
                ))}
              </tr>
              <tr>
                <th className="bg-gray-50 sticky left-0 z-10 border border-gray-200 px-3 py-1 text-left text-xs text-gray-400 font-normal"></th>
                <th colSpan={10} className="bg-gray-50 border border-gray-200 px-2 py-1 text-center text-xs text-gray-400 font-normal">← Actual</th>
                <th colSpan={3} className="bg-blue-50 border border-blue-200 px-2 py-1 text-center text-xs text-blue-400 font-normal">Projected →</th>
              </tr>
            </thead>
            <tbody>
              {KPI_ROWS.map(row => {
                if (row.isSection) {
                  return (
                    <tr key={row.key}>
                      <td colSpan={14} className="bg-gray-100 border border-gray-200 px-3 py-1.5 text-xs font-semibold text-gray-600 uppercase tracking-wide sticky left-0">
                        {row.label}
                      </td>
                    </tr>
                  );
                }
                return (
                  <tr key={row.key} className={`hover:bg-gray-50 ${row.highlight ? 'bg-blue-50/40' : ''}`}>
                    <td className={`sticky left-0 z-10 border border-gray-200 px-3 py-2 text-xs font-medium ${row.highlight ? 'bg-blue-50 text-blue-800' : 'bg-white text-gray-700'}`}
                      style={{paddingLeft: `${12 + (row.indent || 0) * 8}px`}}>
                      {row.label}
                      {row.editable && <span className="ml-1 text-gray-400 text-xs">✎</span>}
                    </td>
                    {/* Actual columns */}
                    {WEEKS_ACTUAL.map((w, ci) => (
                      <td key={w} className={`border border-gray-200 px-2 py-2 text-right text-xs text-gray-600 ${row.highlight ? 'font-semibold' : ''}`}>
                        {fmt(getCellValue(row.key, ci), row.key)}
                      </td>
                    ))}
                    {/* Projected columns */}
                    {WEEKS_PROJ.map((w, pi) => {
                      const colIdx = 10 + pi;
                      const isEditing = editingCell?.rowKey === row.key && editingCell?.wIdx === pi;
                      const val = getCellValue(row.key, colIdx);
                      const isEditable = row.editable && canEdit;
                      return (
                        <td key={w}
                          onClick={() => handleCellClick(row.key, colIdx)}
                          className={`border border-blue-200 px-2 py-2 text-right text-xs
                            ${row.highlight ? 'bg-blue-100 font-semibold text-blue-900' : 'bg-blue-50/60 text-gray-700'}
                            ${isEditable ? 'cursor-pointer hover:bg-blue-100 hover:ring-1 hover:ring-blue-400 ring-inset' : ''}
                          `}>
                          {isEditing ? (
                            <input autoFocus type="number" value={tempVal}
                              onChange={e => setTempVal(e.target.value)}
                              onBlur={commitEdit}
                              onKeyDown={e => { if(e.key==='Enter') commitEdit(); if(e.key==='Escape') setEditingCell(null); }}
                              className="w-full bg-white border border-blue-400 rounded px-1 py-0.5 text-xs text-right focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          ) : (
                            <span>{fmt(val, row.key)}</span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals & Toasts */}
      <ReviewModal changes={reviewChanges} onSave={handleSaveReview} onDiscard={() => setReviewChanges(null)} />

      {savedToast && (
        <div className="fixed bottom-6 right-6 bg-green-600 text-white px-5 py-3 rounded-lg shadow-lg text-sm z-50">
          ✓ OTB saved successfully
        </div>
      )}
      {accessToast && (
        <div className="fixed bottom-6 right-6 bg-gray-800 text-white px-5 py-3 rounded-lg shadow-lg text-sm z-50">
          ⚠ Only Makers can edit projected values
        </div>
      )}
    </div>
  );
}

Object.assign(window, { KpiTable, ReviewModal });
